import tkinter as tk
from PIL import ImageTk, Image
from tkinter import Button  # Add this import line
from tkinter import Frame
from tkinter import LabelFrame
from tkinter import Label
from tkinter import ttk







class student:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("face recognition system")

        # First image
        img = Image.open(r"ziyad.png")
        self.photoimg = ImageTk.PhotoImage(img)
        img = img.resize((500, 130), Image.LANCZOS) 
        
        f_lbl = tk.Label(self.root, image=self.photoimg)
        f_lbl.place(x=0, y=0, width=500, height=130)

        # Second Image
        img1 = Image.open(r"ziyad.png")
        self.photoimg1 = ImageTk.PhotoImage(img1)
        img1 = img1.resize((500, 130), Image.LANCZOS) 
                
        f_lbl = tk.Label(self.root, image=self.photoimg1)
        f_lbl.place(x=500, y=0, width=500, height=130)       

        # Third image
        img2 = Image.open(r"ziyad.png")
        self.photoimg2 = ImageTk.PhotoImage(img2)
        img2 = img2.resize((500, 130), Image.LANCZOS) 
                
        f_lbl = tk.Label(self.root, image=self.photoimg2)
        f_lbl.place(x=1000, y=0, width=500, height=130)

        # Big image
        img3 = Image.open(r"ziyad.png")
        self.photoimg3 = ImageTk.PhotoImage(img3)
        img3 = img3.resize((1530, 710), Image.LANCZOS)
        
        bg_img = tk.Label(self.root, image=self.photoimg3)
        bg_img.place(x=0, y=130, relwidth=1, height=710)
        
        title_lbl = tk.Label(bg_img, text="Student Management System", font=("times new roman", 35, "bold"), bg="red", fg="White")
        title_lbl.place(x=0, y=0, width=1500, height=45)
        
        main_frame=Frame(bg_img,bd=2)
        main_frame.place(x=20,y=50,width=1300,height=600)
        
        #left label frame
        Left_frame=LabelFrame(main_frame,bd=2,relief='ridge',text="Student Details",font=("times new roman",12,"bold"))
        Left_frame.place(x=-10,y=10,width=700,height=500)
        
        img_left= Image.open(r"st1.jpg")
        self.photoimg_left = ImageTk.PhotoImage(img_left)
        img_left= img_left.resize((720, 150), Image.LANCZOS) 
                
        f_lbl = tk.Label(Left_frame,image=self.photoimg_left)
        f_lbl.place(x=0, y=0, width=720, height=150)
        
        #current course

        Current_course_frame=LabelFrame(Left_frame,bd=2,bg="white",relief='ridge',text="Current Subject",font=("times new roman",12,"bold"))
        Current_course_frame.place(x=0,y=35,width=692,height=130)

        #department
        dep_label=Label(Current_course_frame,text="Department",font=("times new roman",13,"bold"),bg="white")
        dep_label.grid(row=0,column=0,padx=10)
        
        dep_combo=ttk.Combobox(Current_course_frame,font=("times new roman",13,"bold"),width=20,state="readonly")
        dep_combo["values"]=("Select Department","Maths","English","Chemistry","Biology","Physics")
        dep_combo.current(0)
        dep_combo.grid(row=0,column=1,padx=2,pady=10,sticky="w")

        #course
        course_label=Label(Current_course_frame,text="Course",font=("times new roman",13,"bold"),bg="white")
        course_label.grid(row=0,column=2,padx=10,sticky="w")

        course_combo=ttk.Combobox(Current_course_frame,font=("times new roman",13,"bold"),width=20,state="readonly")
        course_combo["values"]=("Select Department","Maths","English","Chemistry","Biology","Physics")
        course_combo.current(0)
        course_combo.grid(row=0,column=3,padx=2,pady=10,sticky="w")

        #year
        year_label=Label(Current_course_frame,text="Year",font=("times new roman",13,"bold"),bg="white")
        year_label.grid(row=1,column=0,padx=10,sticky="w")

        year_combo=ttk.Combobox(Current_course_frame,font=("times new roman",13,"bold"),width=20,state="readonly")
        year_combo["values"]=("Select Year","2012","2013","2014","2015","2016")
        year_combo.current(0)
        year_combo.grid(row=1,column=1,padx=2,pady=10,sticky="w")

        #semister
        course_label=Label(Current_course_frame,text="Semister",font=("times new roman",13,"bold"),bg="white")
        course_label.grid(row=1,column=2,padx=10,sticky="w")

        course_combo=ttk.Combobox(Current_course_frame,font=("times new roman",13,"bold"),width=20,state="readonly")
        course_combo["values"]=("Select Department","Maths","English","Chemistry","Biology","Physics")
        course_combo.current(0)
        course_combo.grid(row=1,column=3,padx=2,pady=10,sticky="w")

        #Class Student Information
        class_student_frame = LabelFrame(Left_frame, bd=2, bg="white", relief='ridge', text="Class Student information", font=("times new roman", 12, "bold"))
        class_student_frame.place(x=0, y=150, width=692, height=270)

        #student id
        studentId_label = Label(class_student_frame, text="Student ID:", font=("times new roman", 13, "bold"), bg="white")
        studentId_label.grid(row=0, column=0,padx=10,pady=5,sticky="w")

        studentID_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        studentID_entry.grid(row=0, column=1, padx=10,pady=5,sticky="w")

        #student name
        studentName_label = Label(class_student_frame, text="Student Name:", font=("times new roman", 13, "bold"), bg="white")
        studentName_label.grid(row=0, column=2,padx=2,pady=5,sticky="w")

        studentName_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        studentName_entry.grid(row=0, column=3, padx=10,pady=5,sticky="w")

        #class division
        class_div_label=Label(class_student_frame, text="Class:", font=("times new roman", 13, "bold"), bg="white")
        class_div_label.grid(row=1, column=0,padx=10,pady=5,sticky="w")

        class_div_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        class_div_entry.grid(row=1, column=1, padx=10,pady=5,sticky="w")

        #section
        section_label=Label(class_student_frame, text="section:", font=("times new roman", 13, "bold"), bg="white")
        section_label.grid(row=1, column=2,padx=10,pady=5,sticky="w")

        section_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        section_entry.grid(row=1, column=3, padx=10,pady=5,sticky="w")
        
        
        #Gender
        gender_label=Label(class_student_frame, text="Gender:", font=("times new roman", 13, "bold"), bg="white")
        gender_label.grid(row=2, column=0,padx=10,pady=5,sticky="w")

        gender_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        gender_entry.grid(row=2, column=1, padx=10,pady=5,sticky="w")

        #roll No
        roll_no_label=Label(class_student_frame, text="Roll No:", font=("times new roman", 13, "bold"), bg="white")
        roll_no_label.grid(row=2, column=2,padx=10,pady=5,sticky="w")

        roll_no_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        roll_no_entry.grid(row=2, column=3, padx=10,pady=5,sticky="w")

        #student phone No
        student_phone_label=Label(class_student_frame, text="Student Phone No:", font=("times new roman", 13, "bold"), bg="white")
        student_phone_label.grid(row=3, column=0,padx=10,pady=5,sticky="w")

        student_phone_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        student_phone_entry.grid(row=3, column=1, padx=10,pady=5,sticky="w")

        #Address
        address_label=Label(class_student_frame, text="Address:", font=("times new roman", 13, "bold"), bg="white")
        address_label.grid(row=3, column=2,padx=10,pady=5,sticky="w")

        roll_no_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        roll_no_entry.grid(row=3, column=3, padx=10,pady=5,sticky="w")

        #Home Teacher name
        teacher_name_label=Label(class_student_frame, text="Teacher Name:", font=("times new roman", 13, "bold"), bg="white")
        teacher_name_label.grid(row=4, column=0,padx=10,pady=5,sticky="w")

        teacher_name_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        teacher_name_entry.grid(row=4, column=1, padx=10,pady=5,sticky="w")

        #Home Teacher phone no
        teacher_phone_label=Label(class_student_frame, text="Teacher Phone No:", font=("times new roman", 13, "bold"), bg="white")
        teacher_phone_label.grid(row=4, column=2,padx=10,pady=5,sticky="w")

        teacher_phone_entry =ttk.Entry(class_student_frame, width=20, font=("times new roman", 13, "bold"))
        teacher_phone_entry.grid(row=4, column=3, padx=10,pady=5,sticky="w")

        #radio Buttons
        radiobtn1=ttk.Radiobutton(class_student_frame,text="take photo sample",value="yes")
        radiobtn1.grid(row=6,column=0)

        radiobtn2=ttk.Radiobutton(class_student_frame,text="No photo sample",value="yes")
        radiobtn2.grid(row=6,column=1)

        #bbuttons frame
        btn_frame=Frame(class_student_frame,bd=2,relief='ridge',bg="white")
        btn_frame.place(x=0,y=170,width=690,height=35)

        save_btn=Button(btn_frame,text="Save",width=17,height=0,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        save_btn.grid(row=0,column=0)

        update_btn=Button(btn_frame,text="Update",width=17,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        update_btn.grid(row=0,column=1)

        delete_btn=Button(btn_frame,text="Delete",width=17,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        delete_btn.grid(row=0,column=2)

        reset_btn=Button(btn_frame,text="Reset",width=17,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        reset_btn.grid(row=0,column=3)

        btn_frame=Frame(class_student_frame,bd=2,relief='ridge',bg="white")
        btn_frame.place(x=0,y=200,width=715,height=35)

        takephoto_btn=Button(btn_frame,text="Take Photo",width=34,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        takephoto_btn.grid(row=0,column=0)

        updatephoto_btn=Button(btn_frame,text="Update Photo",width=34,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        updatephoto_btn.grid(row=0,column=1)
        
        #Right label frame
        
        Right_frame=LabelFrame(main_frame,bd=2,relief='ridge',text="Student Details",font=("times new roman",12,"bold"))
        Right_frame.place(x=690,y=10,width=555,height=440)

        img_right= Image.open(r"st2.jpg")
        self.photoimg_right = ImageTk.PhotoImage(img_right)
        img_right= img_right.resize((750, 150), Image.LANCZOS) 
                
        f_lbl = tk.Label(Right_frame,image=self.photoimg_right)
        f_lbl.place(x=0, y=0, width=720, height=150)

        # search system
        search_frame = LabelFrame(Right_frame, bd=2, bg="white", relief='ridge', text="Search", font=("times new roman", 12, "bold"))
        search_frame.place(x=0, y=150, width=550, height=70)
        
        search_label=Label(search_frame, text="Search:", font=("times new roman", 15, "bold"),width=5, bg="white",fg="red")
        search_label.grid(row=0, column=0,padx=2,pady=5,sticky="w")

        search_combo=ttk.Combobox(search_frame,font=("times new roman",13,"bold"),state="readonly",width=10)
        search_combo["values"]=("Select","Roll_No","Class","Name")
        search_combo.current(0)
        search_combo.grid(row=0,column=1,padx=1,pady=10,sticky="w")

        search_entry =ttk.Entry(search_frame, width=10, font=("times new roman", 13, "bold"))
        search_entry.grid(row=0, column=2, padx=2,pady=5,sticky="w")

        search_btn=Button(search_frame,text="Search",width=12,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        search_btn.grid(row=0,column=3)

        showAll_btn=Button(search_frame,text="Show All",width=12,font=("times new roman", 13, "bold"),bg="blue",fg="white")
        showAll_btn.grid(row=0,column=4)

        #table
        
        table_frame = Frame(Right_frame, bd=2, bg="white", relief='ridge')
        table_frame.place(x=0, y=210, width=550, height=200)

        scroll_x=ttk.Scrollbar(table_frame,orient="horizontal")
        scroll_y=ttk.Scrollbar(table_frame,orient="vertical")

        self.student_table=ttk.Treeview(table_frame,column=("dep","course","year","sem","studentname","roll", "gender","class","sec",
        "stphone","address","tname","teachphone","photo"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        scroll_x.pack(side="bottom",fill="x")
        scroll_y.pack(side="bottom",fill="y")
        scroll_x.config(command=self.student_table.xview)
        scroll_y.config(command=self.student_table.yview)
        
        self.student_table.heading("dep",text="Subject")
        self.student_table.heading("course",text="teacher")
        self.student_table.heading("year",text="Year")
        self.student_table.heading("sem",text="Semister")
        self.student_table.heading("studentname",text="Student Name")
        self.student_table.heading("roll",text="Student Roll No")
        self.student_table.heading("gender",text="Gender")
        self.student_table.heading("class",text="Class")
        self.student_table.heading("sec",text="Section")
        self.student_table.heading("stphone",text="Student Phone No")
        self.student_table.heading("address",text="Student Address")
        self.student_table.heading("tname", text="Teacher Name")
        self.student_table.heading("teachphone",text="Teacher Phone No")
        self.student_table.heading("photo",text="Photo")
        self.student_table["show"]="headings"

        self.student_table.pack(fill="both",expand=1)

        
        self.student_table.column("dep",width=100)
        self.student_table.column("course",width=100)
        self.student_table.column("year",width=100)
        self.student_table.column("sem",width=100)
        self.student_table.column("studentname",width=100)
        self.student_table.column("roll",width=100)
        self.student_table.column("gender",width=100)
        self.student_table.column("class",width=100)
        self.student_table.column("sec",width=100)
        self.student_table.column("stphone",width=100)
        self.student_table.column("address",width=100)
        self.student_table.column("tname",width=100)
        self.student_table.column("teachphone",width=100)
        self.student_table.column("photo",width=150)
        
if __name__ == "__main__":
    root = tk.Tk()
    obj =student(root)
    root.mainloop()      
